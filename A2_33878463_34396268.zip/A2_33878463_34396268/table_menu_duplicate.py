"""
Assignment 2, Task 1.
This program obtains a dataset of tables from the file table_data.py and performs 3 function with them
1. List the index of the table alongside its respective number of rows and columns
2. Display the table itself when its index is provided 
3. Create a duplicate of an existing table and store that table in table_data.py
"""
# Import the necessary modules 
import table_data
import copy
from tabulate import tabulate

# Initialise the lists to store each variable
Index = []
Columns = []
Rows = []

# The copy counter helps with the naming of the duplicate tables 
copyCounter = 1

# Function for the main menu to be displayed
def mainMenu():
    """
    When called this function prints out the main menu onto the console
    @param: None
    @return: None 
    """
    print("==================================")
    print("Enter your choice:")
    print("1. List tables.")
    print("2. Display table.")
    print("3. Duplicate table.")
    print("0. Quit.")
    print("==================================")

# Function for listing the tables 
def option1():
    """
    Displays a table containing the index of each table alongside their 
    respective number of columns and rows
    @param: None
    @return: A table formatted using tabulate that displays each table's core information
    """
    value = 0
    global Index
    global Columns
    global Rows
    Index.clear()
    Columns.clear()
    Rows.clear()
    # Obtains the informaiton and inserts it into the lists index, columns and rows
    for i in table_data.tables:
        Index.append(value)
        value += 1
    for i in table_data.tables: 
        numColumns = len(i[0])
        Columns.append(numColumns)
        numRows = len(i)
        Rows.append(numRows)
    # Displays the information in index, columns and rows in the appropriate form
    tableData = list(zip(Index, Columns, Rows))
    headers = ["Index", "Columns", "Rows"]
    listTables = tabulate(tableData, headers, tablefmt="simple")
    return listTables

# Function for displaying the table 
def option2():
    """
    Asks user for the index of the table they would like to display 
    and displays the table and its contents 
    @param: None
    @return: The desired table requested by the user and its contents 
    """
    # Obtains and validates the input (table index)
    # Ensures that table index is witin range
    tableIndexInput = int(input("Choose a table index (to display):\n"))
    while True:
        if 0 <= tableIndexInput <len(table_data.tables):
            break
        else: 
            print("Incorrect table index. Try again.")
            tableIndexInput = int(input("Choose a table index (to display):\n"))
        
    # Prints the table in the appropriate format
    tableToPrint = table_data.tables[tableIndexInput]
    printingTheTable = tabulate(tableToPrint[1:], headers=tableToPrint[0], tablefmt="simple")
    return printingTheTable

# Function for duplicating an existing table 
def option3():
    """
    Asks the user for a table's index and creates a duplicate of the table with a different name
    @param: None
    @return: The duplicate version of the table requested by the user
    """
    # Obtains and validates the input (table index)
    # Ensures that table index is witin range
    tableCopyIndexInput = int(input("Choose a table index (to duplicate):\n"))
    while True:
        if 0 <= tableCopyIndexInput <len(table_data.tables):
            break
        else: 
            print("Incorrect table index. Try again.")
            tableCopyIndexInput = int(input("Choose a table index (to duplicate):\n"))
    # Duplicates the table in the appropriate format
    # Assigns the duplicated table to a new name
    global copyCounter
    tableToCopy = table_data.tables[tableCopyIndexInput]
    copiedTableName = f"copiedTable{copyCounter}"
    globals()[copiedTableName] = copy.deepcopy(tableToCopy)
    table_data.tables.append(globals()[copiedTableName])
    copyCounter += 1

# Runs the program in a loop until the user quits the program 
while True:
    mainMenu()

    while True: 
        try: 
            UserChoice = int(input(""))
            break
        except (ValueError, TypeError): 
            mainMenu()

    if UserChoice == 1:
        print(option1())
    elif UserChoice == 2:
        print(option2())
    elif UserChoice == 3:
        option3()
    elif UserChoice == 0:
        break

