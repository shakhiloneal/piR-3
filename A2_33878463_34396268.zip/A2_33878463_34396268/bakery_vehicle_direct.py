"""
Assignment 2, Task 8.
This program obtains a departure and destination ID and computes the distance between
the two locations. It then calculates how long the travel time would be from the departure city
to the destination city for a total of 5 different mediums and speeds of transport 
"""
# Import the required modules
from city_data import city_data
from geopy.distance import geodesic
from abc import ABC, abstractclassmethod
import math

class vehicle(ABC):
    """
    Abstract class called vehicle defines the common interface and attributes for all types of vehicles.
    Subclasses must implement the abstract methods defined here and could build upon it 

    Attributes: 
        distance (integer): The total distance between the departure city and the destination city
    
    Methods: 
        __init__(self, distance: integer)
            Initialises instance of vehicle class with given distance 
        
        travel_times(self)
            Abstract method that intends to calculate time taken for set vehicle to travel the distance at set speed.
            Subclasses must use this method
    """
    def __init__(self, distance):
        """
         Initialises instance of vehicle class with given distance 

         Args: 
            distance (integer): The total distance between the departure city and the destination city
        """
        pass
    @abstractclassmethod
    def travel_times(self):
        """
        Abstract method that intends to calculate time taken for set vehicle to travel the distance at set speed.
        Subclasses must use this method

        Returns: 
            Integer: Number of hours taken to travel the distance 
        """
        pass

class CrepeCar(vehicle):
    """
    A class representing the Crappy Crepe Car. 
    This class inherits from the abstract class vehicle and provides the implementation for the Crepe Car

    Attributes: 
        distance (integer): The total distance between the departure city and the destination city
        speed (integer): Speed of the Crepe Car in kilometers per hour
    
    Methods: 
        __init__(self, distance: integer, speed: integer)
            Initialises instance of Crappy Crepe Car with given distance and fixed speed
        
        travel_times(self)
            Calculates number of hours taken for Crepe Car to travel the distance between the cities 
    """
    def __init__(self, distance, speed):
        """
        Initialises instance of Crappy Crepe Car with given distance and fixed speed

         Args: 
            distance (integer): The total distance between the departure city and the destination city
            speed (integer): Speed of the Crepe Car in kilometers per hour
        """
        self.distance = distance
        self.speed = speed
    def travel_times(self):
        """
        Calculates number of hours taken for Crepe Car to travel the distance between the cities 

        Returns: 
            String: A string representing the number of hours taken for the crepe car to travel the distance between the cities 
        """
        travelDuration = (math.ceil(self.distance / self.speed))
        return (str(travelDuration) + " hours")

class DonutDinghy(vehicle):
    """
    A class representing the Diplomacy Donut Dinghy. 
    This class inherits from the abstract class vehicle and provides the implementation for the Diplomacy Donut Dinghy

    Attributes: 
        distance (integer): The total distance between the departure city and the destination city
        domesticSpeed (integer): Speed of the Diplomacy Donut Dinghy in kilometers per hour when travelling between cities in same country
        internationalSpeed (integer): Speed of the Diplomacy Donut Dinghy in kilometers per hour when travelling between cities that are "primary" capitals
    
    Methods: 
        __init__(self, distance: integer, domesticSpeed: integer, internationalSpeed: integer)
            Initialises instance of Diplomacy Donut Dinghy with given distance for a domestic and internatinal speed based on the cities location
        
        travel_times(self)
            Calculates number of hours taken for Diplomacy Donut Dinghy to travel the distance between two cities in same country
        
        travel_times_international(self)
            Calcualtes number of hours taken for Diplomacy Donut Dinghy to travel the distance between two "primary" capital cities
    """
    def __init__(self, distance, domesticSpeed, internationalSpeed):
        """
        Initialises instance of Diplomacy Donut Dinghy with given distance for a domestic and internatinal speed based on the cities location

         Args: 
            distance (integer): The total distance between the departure city and the destination city
            domesticSpeed (integer): Speed of the Diplomacy Donut Dinghy in kilometers per hour when travelling between cities in same country
            internationalSpeed (integer): Speed of the Diplomacy Donut Dinghy in kilometers per hour when travelling between cities that are "primary" capitals
        """
        self.distance = distance
        self.domesticSpeed = domesticSpeed
        self.internationalSpeed = internationalSpeed   
    def travel_times(self):
        """
        Calculates number of hours taken for Diplomacy Donut Dinghy to travel the distance between two cities in same country

        Returns: 
            String: A string representing the number of hours taken for the Diplomacy Donut Dinghy to travel the distance between the cities 
        """
        travelDurationDomestic = (math.ceil(self.distance / self.domesticSpeed))
        return (str(travelDurationDomestic) + " hours") 
    def travel_times_international(self):
        """
        Calcualtes number of hours taken for Diplomacy Donut Dinghy to travel the distance between two "primary" capital cities

        Returns: 
            String: A string representing the number of hours taken for the Diplomacy Donut Dinghy to travel the distance between the cities 
        """
        travelDurationInternational = (math.ceil(self.distance / self.internationalSpeed))
        return (str(travelDurationInternational) + " hours") 

class TarteTrolley(vehicle):
    """
    A class representing the Teleporting Tarte Trolley. 
    This class inherits from the abstract class vehicle and provides the implementation for the Teleporting Tarte Trolley

    Attributes: 
        distance (integer): The total distance between the departure city and the destination city
    
    Methods: 
        __init__(self, distance: integer)
            Initialises instance of Teleporting Tarte Trolley with given distance between the cities 
        
        travel_times(self)
            Calculates number of hours taken for Teleporting Tarte Trolley to travel the distance between two cities less than 2000km apart
        
        travel_times_3000(self)
            Calcualtes number of hours taken for Teleporting Tarte Trolley to travel the distance between two cities less than 3000km apart
    """
    def __init__(self, distance):
        """
        Initialises instance of Teleporting Tarte Trolley with given distance between the cities 

         Args: 
            distance (integer): The total distance between the departure city and the destination city
        """
        self.distance = distance
    def travel_times(self):
        """
        Calculates number of hours taken for Teleporting Tarte Trolley to travel the distance between two cities less than 2000km apart

        Returns: 
            String: A string representing the number of hours taken for the Teleporting Tarte Trolley to travel the distance between the cities 
            
            Else returns a string "Infinity" if time taken cannot be computed
        """
        if distance <= 2000:
            travelDuration = "6 hours"
            return travelDuration
        else:
            return "Infinity"
    def travel_times_3000(self):
        """
        Calcualtes number of hours taken for Teleporting Tarte Trolley to travel the distance between two cities less than 3000km apart

        Returns: 
            String: A string representing the number of hours taken for the Teleporting Tarte Trolley to travel the distance between the cities 

            Else returns a string "Infinity" if time taken cannot be computed
        """
        if distance <= 3000:
            travelDuration = "8 hours"
            return travelDuration
        else: 
            return "Infinity"

print("""Delivering baked goods to 363 cities.
Bakery vehicles:
 0. Crappy Crepe Car (crappy speed: 250 km/h)
 1. Diplomacy Donut Dinghy (domestic speed: 100 km/h | international speed: 500 km/h)
 2. Diplomacy Donut Dinghy (domestic speed: 50 km/h | international speed: 800 km/h)
 3. Teleporting Tarte Trolley (blink time: 6 h | blink range: 2000 km)
 4. Teleporting Tarte Trolley (blink time: 8 h | blink range: 3000 km)""")

# Obtain ID for departure city and find its location and name
departureInput = int(input("Enter the ID of the departure city:\n"))
for lists in city_data:
    if lists[8] == str(departureInput):
        # Obtain departure city coordinates 
        departureLat = float(lists[1])
        departureLng = float(lists[2])
        # Obtain departure city capital
        departureCapital = lists[6]
        # Obtain departure city country
        departureCountry = lists[3]
        # Obtain departure city name
        departureName = lists[0]
        break

# Obtain ID for destination city and find its location and name
destinationInput = int(input("Enter the ID of the destination city:\n"))
for lists in city_data:
    if lists[8] == str(destinationInput):
        # Obtain destination city coordinates 
        destinationLat = float(lists[1])
        destinationLng = float(lists[2])
        # Obtain destination city capital
        destinationCapital = lists[6]
        # Obtain destination city country
        destinationCountry = lists[3]
        # Obtain destination city name
        destinationName = lists[0]
        break

# Calculate distance between the cities
point1 = (departureLat, departureLng)
point2 = (destinationLat, destinationLng) 
distance = math.ceil(geodesic(point1, point2).kilometers)

# Calcualte travel time for Crappy Crepe Car
crepeCarTravelTime = CrepeCar(distance, 250).travel_times()

# Calculate travel time for Diplomacy Donut DonutDinghy (Version 1):
# Between two cities in same country
if departureCountry == destinationCountry:
    donutDinghyTravelTime1 = DonutDinghy(distance, 100, 500).travel_times()
# Between two "primary" capital cities
elif departureCapital == "primary" and destinationCapital == "primary":
    donutDinghyTravelTime1 = DonutDinghy(distance, 100, 500).travel_times_international()
else: 
    donutDinghyTravelTime1 = "Infinity"

# Calculate travel time for Diplomacy Donut DonutDinghy (Version 2):
# Between two cities in same country
if departureCountry == destinationCountry:
    donutDinghyTravelTime2 = DonutDinghy(distance, 50, 800).travel_times()
# Between two "primary" capital cities
elif departureCapital == "primary" and destinationCapital == "primary":
    donutDinghyTravelTime2 = DonutDinghy(distance, 50, 800).travel_times_international()
else: 
    donutDinghyTravelTime2 = "Infinity"

# Calculate travel time for Teleporting Tarte Trolley (version 1 - less than 2000km)
tarteTrolleyTravelTime1 = TarteTrolley(distance).travel_times()

# Calculate travel time for Teleporting Tarte Trolley (version 2 - less than 3000km)
tarteTrolleyTravelTime2 = TarteTrolley(distance).travel_times_3000()

# Print out the results
print(f"Direct travel times from {departureName} to {destinationName}:")
print(f""" 0. {crepeCarTravelTime}
 1. {donutDinghyTravelTime1}
 2. {donutDinghyTravelTime2}
 3. {tarteTrolleyTravelTime1}
 4. {tarteTrolleyTravelTime2}""")

