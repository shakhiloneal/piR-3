"""
Assignment 2, Task 3.
This program obtains a dataset of tables from the file table_data.py and performs 7 function with them
1. List the index of the table alongside its respective number of rows and columns
2. Display the table itself when its index is provided 
3. Create a duplicate of an existing table and store that table in table_data.py
4. Create a table based on the columns the user selects from another table
5. Deletes a table from the list and table_data.py
6. Asks user for a table's index and column index and removes the column from the table. It then saves this as the existing table
7. Restores the table that has been deleted from 'listTablesGlobal' back into it.
"""
# Import the necessary modules 
import table_data
import copy
from tabulate import tabulate

# Initialise the lists to store each variable
Index = []
Columns = []
Rows = []

# The copy counter helps with the naming of the duplicate tables 
copyCounter = 1

# The create counter helps with the naming of the newly created table
createCounter = 1

# Function for the main menu to be displayed
def mainMenu():
    """
    When called this function prints out the main menu onto the console
    @param: None
    @return: None 
    """
    print("==================================")
    print("Enter your choice:")
    print("1. List tables.")
    print("2. Display table.")
    print("3. Duplicate table.")
    print("4. Create table.")
    print("5. Delete table.")
    print("6. Delete column.")
    print("7. Restore table.")
    print("0. Quit.")
    print("==================================")

# Function that lists the tables 
def option1():
    """
    Displays a table containing the index of each table alongside their 
    respective number of columns and rows
    @param: None
    @return: A table formatted using tabulate that displays each table's core information
    """
    # Calls the list of tables that exists in the document 
    global listTablesGlobal
    return listTablesGlobal

# Function for displaying the table 
def option2():
    """
    Asks user for the index of the table they would like to display 
    and displays the table and its contents 
    @param: None
    @return: The desired table requested by the user and its contents 
    """
    # Obtains and validates the input (table index)
    # Ensures that table index is witin range
    global Index
    tableIndexInput = int(input("Choose a table index (to display):\n"))
    while True:
        if tableIndexInput in Index:
            break
        else: 
            print("Incorrect table index. Try again.")
            tableIndexInput = int(input("Choose a table index (to display):\n")) 
 
    # Prints the table in the appropriate format
    tableToPrint = table_data.tables[tableIndexInput]
    printingTheTable = tabulate(tableToPrint[1:], headers=tableToPrint[0], tablefmt="simple")
    return printingTheTable

# Function for duplicating an existing table 
def option3():
    """
    Asks the user for a table's index and creates a duplicate of the table with a different name
    @param: None
    @return: The duplicate version of the table requested by the user
    """
    # Obtains and validates the input (table index)
    # Ensures that table index is witin range
    tableCopyIndexInput = int(input("Choose a table index (to duplicate):\n"))
    while True:
        if tableCopyIndexInput in Index:
            break
        else: 
            print("Incorrect table index. Try again.")
            tableCopyIndexInput = int(input("Choose a table index (to duplicate):\n"))
    # Duplicates the table and assigns the duplicated version to a new name
    global copyCounter
    tableToCopy = table_data.tables[tableCopyIndexInput]
    copiedTableName = f"copiedTable{copyCounter}"
    globals()[copiedTableName] = copy.deepcopy(tableToCopy)
    table_data.tables.append(globals()[copiedTableName])
    copyCounter += 1
    addingTable()

# Function that creates a new table that is made up of the columns from a current table
def option4():
    """
    Asks the user for a table's index and then asks the user to select columns from that table to keep
    This information is then used by the function to form a new table with a new name
    @param: None
    @return: None
    """
    # Obtains and validates the input (table index)
    # Ensures that table index is witin range
    tableCreateIndexInput = int(input("Choose a table index (to create from):\n"))
    while True:
        if tableCreateIndexInput in Index:
            break
        else:
            print("Incorrect table index. Try again.")
            tableCreateIndexInput = int(input("Choose a table index (to create from):\n"))
    
    # Obtains the information regarding which columns to keep and formats it 
    columnsToKeep = input("Enter the comma-separated indices of the columns to keep:\n")
    columns = columnsToKeep.split(',')
    listOfColumns = []
    for i in columns:
        listOfColumns.append(int(i))
    
    # Creates the table in the appropriate table format
    # Assigns the created table a new name 
    global createCounter 
    newTable = [[row[i] for i in listOfColumns] for row in (table_data.tables[tableCreateIndexInput])]
    createdTableName = f"createdTable{createCounter}"
    globals()[createdTableName] = newTable
    table_data.tables.append(globals()[createdTableName])
    createCounter += 1 
    # Calls the adding table function to create and add the table
    addingTable()

# Function that deletes an existing table
def option5():
    """
    Asks the user for a table's index and then removes that table from listTablesGlobal and table_data.py
    @param: None
    @return: 'listTablesGlobal', a table that contains the core information of tables stored in table_data.py
    The return value deletes the table selected by the user from the 'listTablesGlobal' table and returns it
    """
    # Obtains index of table that needs to be deleted 
    tableToDelete = int(input("Choose a table index (for table deletion):\n"))
    global Index 
    global Rows
    global Columns
    # Checks to ensure that the table index exists
    while True: 
        if tableToDelete in Index:
            break
        else: 
            print("Incorrect table index. Try again.")
            tableToDelete = int(input("Choose a table index (for table deletion):\n"))
    
    # Removes the index from the table and returns a list of tables with the table removed
    indexToRemove = Index.index(tableToDelete)
    Rows.pop(indexToRemove)
    Columns.pop(indexToRemove)
    Index.remove(tableToDelete)
    tableData = list(zip((Index), Columns, Rows))     
    headers = ["Index", "Columns", "Rows"]
    global listTablesGlobal
    listTablesGlobal = tabulate(tableData, headers, tablefmt="simple")
    return listTablesGlobal

# Function that deletes a column in a table
def option6():
    """
    Asks the user for a table's index as well as the index of the columns to be removed. 
    The columns are then removed from the table and saved onto 'listTablesGlobal'
    @param: None
    @return: None
    """
    global Index
    global Columns

    # Obtains the table index for which column deletion needs to occur
    tableForColumnDelete = int(input("Choose a table index (for column deletion):\n"))
    
    # Ensures the table index exists 
    while True:
        if tableForColumnDelete in Index:
            break
        else:
            print("Incorrect table index. Try again.")
            tableForColumnDelete = int(input("Choose a table index (for column deletion):\n"))
    
    # Obtains the column that needs to be deleted
    columnToDelete = int(input("Enter the index of the column to delete:\n"))
    tableIndex = Index.index(tableForColumnDelete)
    Columns[tableIndex] -= 1

    # Deletes column from table and updates the 'list of tables' table
    for row in (table_data.tables[tableForColumnDelete]):
        if columnToDelete < len(row):
            row.pop(columnToDelete)
    tableData = list(zip((Index), Columns, Rows))     
    headers = ["Index", "Columns", "Rows"]
    global listTablesGlobal
    listTablesGlobal = tabulate(tableData, headers, tablefmt="simple")

# Function that restores a table that was deleted
def option7():
    """
    Asks the user for the index of the table to be restored. Obtains restoration data from the list tables
    in table_data.py and stores this back into 'listTablesGlobal'
    @param: None
    @return: None
    """
    global Index 
    global Rows
    global Columns
    global listTablesGlobal

    # Obtains index of the table that needs to be restored 
    tableForRestoration = int(input("Choose a table index (for restoration):\n"))
    
    # Ensures the table index exists 
    while True:
        if (0 <= tableForRestoration < len(table_data.tables)) and tableForRestoration not in Index:
            break
        else:
            print("Incorrect table index. Try again.")
            tableForRestoration = int(input("Choose a table index (for restoration):\n"))
    
    # Obtains data regarding table to be restored from the tables list in table_data
    table_data.tables[tableForRestoration]
    Index.append(tableForRestoration)
    Index = sorted(Index)
    indexToAdd = sorted(Index).index(tableForRestoration)
    tableToRestore = table_data.tables[tableForRestoration]
    numColumns = len(tableToRestore[0])
    Columns.insert(indexToAdd, numColumns)
    numRows = len(tableToRestore)
    Rows.insert(indexToAdd, numRows)
    
    # Updates the "list of tables" table with the restored table's data
    tableData = list(zip((Index), Columns, Rows))     
    headers = ["Index", "Columns", "Rows"]
    listTablesGlobal = tabulate(tableData, headers, tablefmt="simple")

# This functions adds a table to the table 'listTablesGlobal' which stores the core information of the tables
def addingTable():
    """
    Adds the table being created in menuoption4 into 'listTablesGlobal' table
    @param: None
    @return: None
    """
    global value
    Index.append(value)
    value += 1
    numColumns = len((table_data.tables[-1])[0])
    Columns.append(numColumns)
    numRows = len(table_data.tables[-1])
    Rows.append(numRows)
    
    # Replaces the existing 'listTablesGlobal' with the new 'listTablesGlobal' (new table added)
    global listTablesGlobal
    tableData = list(zip((Index), Columns, Rows))     
    headers = ["Index", "Columns", "Rows"]
    listTablesGlobal = tabulate(tableData, headers, tablefmt="simple")

"""
Initialises the 'listTablesGlobal' table by obtaining the table's core information from
the tables list in table_data.py and stores it into 'listTablesGlobal' 
""" 
value = 0
for i in table_data.tables:
    Index.append(value)
    value += 1
for i in table_data.tables: 
    numColumns = len(i[0])
    Columns.append(numColumns)
    numRows = len(i)
    Rows.append(numRows)
tableData = list(zip(Index, Columns, Rows))     
headers = ["Index", "Columns", "Rows"]
listTablesGlobal = tabulate(tableData, headers, tablefmt="simple")

# Runs the program in a loop until the user quits the program 
while True:
    mainMenu()

    while True: 
        try: 
            UserChoice = int(input(""))
            break
        except (ValueError, TypeError): 
            mainMenu()

    if UserChoice == 1:
        print(option1())
    elif UserChoice == 2:
        print(option2())
    elif UserChoice == 3:
        option3()
    elif UserChoice == 4:
        option4()
    elif UserChoice == 5:
        option5()
    elif UserChoice == 6:
        option6()
    elif UserChoice == 7:
        option7()
    elif UserChoice == 0:
        break

